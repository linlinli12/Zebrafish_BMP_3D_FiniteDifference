
% This code is to compare pointwise finite difference simulaton results
% and averaged whole sphere result of elife paper's pSmad data for both WT and chd
% mutant

% data last edit: Aug 10 2019
% update note:  code was update for reading individual result for WT or Chd
% mutant for testing 
%(need modeification for runing parameter sweeping reuslts) 
% author: Linlin Li
function compare_result_wt_chd()
%% setting-----------------------------------------------------------------
% load whold sphere result for wt and chd mutant
% data inculde 47/53/57 three timepoint
% sample_mesh is az/el data for the points
% sample_xyz is the xyz coordinate for r=350
load('sampleSph_pSmad_chdWT_083118.mat')
foldername='main_code';
% !!!!!!!!!floder need to contain both WT and chd mutant reuslt under
% subfolder 'wt' and 'chd'
% how many min cases are going to plot
min_case_number=1;

% set result fild numbers in each wt or chd cases
resultfilen=1;%20;
casenum_onfile=1;%5000;
result_type = 1; % WT == 1 ; Chd mutant ==2

%------------------------- Set where the RSME check-----------------------
RMSD_area='margin'; 
% check whold domain = 'off'
% check on central area = 'central' 
% check on Margin area = 'margin'
% check on top area = 'top'
% check on margin & central midline only = 'margincentral'

%--------------------check if plot parameters------------------------------
% plot parameter distribution only when the parameter has be sample and
% multisimulaiton have been runed
plot_parameters='no'; % check as 'yes' if want to plot parameter maps

load(['../main_code/parameter_set_1.mat'])

%% setting end-------------------------------------------------------------
parameter_all=[];
for para=1:resultfilen
eval(['parameter_all=[parameter_all,parameter_set' num2str(para) '];'])

end

%% normlize exp data for both wt and chd

total_wt=[Avg_wholeSph_47_wt;Avg_wholeSph_53_wt;Avg_wholeSph_57_wt];
nonon_total_wt=total_wt(~isnan(total_wt));
total_wts=sort(nonon_total_wt,'descend');
% find the top 5% of the max level
max_wt=total_wts(round(length(total_wts)*0.005));
nonzero_wts=nonzeros(total_wts);
% find the low 10% of the max level
min_wt=nonzero_wts(round(length(nonzero_wts)*0.9));

total_chd=[Avg_wholeSph_47_chd;Avg_wholeSph_53_chd;Avg_wholeSph_57_chd];
% total_chds=sort(total_chd,'descend');
% max_chd=total_chds(round(length(total_chds)*0.05));
% nonzero_chds=nonzeros(total_chds);
% min_chd=nonzero_chds(round(length(nonzero_chds)*0.9));

% normalize the expriment data by the max and min level for wt
Avg_wholeSph_47_wt=(Avg_wholeSph_47_wt-min_wt)/(max_wt-min_wt);
Avg_wholeSph_53_wt=(Avg_wholeSph_53_wt-min_wt)/(max_wt-min_wt);
Avg_wholeSph_57_wt=(Avg_wholeSph_57_wt-min_wt)/(max_wt-min_wt);
Avg_wholeSph_47_chd=(Avg_wholeSph_47_chd-min_wt)/(max_wt-min_wt);
Avg_wholeSph_53_chd=(Avg_wholeSph_53_chd-min_wt)/(max_wt-min_wt);
Avg_wholeSph_57_chd=(Avg_wholeSph_57_chd-min_wt)/(max_wt-min_wt);

%% WT results comparison
total_RMSD_chd=ones(3,resultfilen*casenum_onfile);
total_RMSD_wt=ones(3,resultfilen*casenum_onfile);
total_RMSD=ones(2,resultfilen*casenum_onfile);
%total_maxBMP_sim=zeros(2,resultfilen*casenum_onfile);
% min_rmsd=1000;
% min_file=zeros(1,2);
% min_case=zeros(1,2);
    min_rmsd=1000;
for t=result_type

    if t==1
        ty='wt';
        c='b';
    else
        ty='chd';
        c='r';
    end
    
    for i=1:resultfilen
        %print out file number
        sprintf('file number %d %s',i,ty)
        
        % exculde the non worked file
        if i~=8 
            if i~=13
        load(['../main_code/grow_result_' num2str(casenum_onfile) '_' num2str(i) '.mat']);
            end
        end 
        
        for j=1:casenum_onfile
            if isempty(Total_BMP{1,j})~=1
            %find maxbmp for specific case
            maxbmp_sim=max(max(Total_BMP{3,j}));
            current_parameter=total_parameters(j);
            %total_maxBMP_sim(t,(i-1)*5000+j)=maxbmp_sim;
                for hpf=[47,53,57]
                    if hpf==47
                        casen=1;
                        cut_z=200;%170;
                    elseif hpf==53
                        casen=2;
                        cut_z=200;%130;
                    else
                        casen=3;
                        cut_z=200;%70;
                    end
                    % get single time BMP and normalize
                    onebmp_sim=Total_BMP{casen,j}./maxbmp_sim;
                    min_z=min(min(mesh_zsphere{casen,1}));

                    foo=sample_xyz(:,3)>min_z & sample_xyz(:,2)>= 0;

                    eval(['onebmp_exp=Avg_wholeSph_' num2str(hpf) '_' ty '(foo,1);']);
                    sample_x=sample_xyz(foo,1);
                    sample_y=sample_xyz(foo,2);
                    sample_z=sample_xyz(foo,3);

                    %eval(['sample_xyz_' num2str(hpf) '=[sample_x,sample_ysample_z];']);

                    %f=griddedInterpolant(mesh_xsphere{casen,j},mesh_ysphere{casen,j},mesh_zsphere{casen,j},onebmp_sim);
                    %interp_sim=f(sample_x,sample_y,sample_z);
                    [mesh_az,mesh_el]=cart2sph(mesh_xsphere{casen,1},mesh_ysphere{casen,1},mesh_zsphere{casen,1});
                    %f.Method = 'Nearest neighbor';
                    f=scatteredInterpolant(mesh_az(:),mesh_el(:),onebmp_sim(:));
                    interp_sim=f(sample_mesh(foo,1),pi/2-sample_mesh(foo,2)); 

                    % sort for Central or margin
                    if strcmp(RMSD_area,'central')==1
                    foo_area=sample_y<=20 & sample_y>=-20;

                    elseif strcmp(RMSD_area,'margin')==1
                    foo_area=sample_z<cut_z;

                    elseif strcmp(RMSD_area,'top')==1
                    foo_area=sample_z>cut_z;
 
                    elseif strcmp(RMSD_area,'margincentral')==1
                    foo_area=(sample_y<=20 & sample_y>=-20) | (sample_z<cut_z);    
                    end
                    
                    interp_sim=interp_sim(foo_area);
                    onebmp_exp=onebmp_exp(foo_area);

                    rmsd=sqrt(sum((interp_sim-onebmp_exp).^2/(length(onebmp_exp))));
                    eval(['total_RMSD_' ty '(casen,(i-1)*casenum_onfile+j)=rmsd;']);


                
%                 %plot the check the sim and interpolated sim result
%                 figure               
%                 hold on
%                 surf(mesh_xsphere{casen,1},mesh_ysphere{casen,1},mesh_zsphere{casen,1},onebmp_sim);
%                 scatter3(sample_x,sample_y,sample_z,[],interp_sim,'filled');
%                 axis equal
%                 
%                 figure
%                 surf(mesh_az,mesh_el,onebmp_sim,onebmp_sim);
%                 hold on
%                 [sample_az,sample_el]=cart2sph(sample_x,sample_y,sample_z);
%                 scatter3(sample_az,sample_el,interp_sim,[],interp_sim,'filled');
%                 
%                 figure
%                 scatter3(sample_x,sample_y,sample_z,[],interp_sim-onebmp_exp,'filled')
%                 axis equal
%                 title(' error of interplated sim and exp data')
%                 colorbar
                end
            end
        end
    end
end

total_RMSD(1,:)=mean(total_RMSD_wt);
total_RMSD(2,:)=mean(total_RMSD_chd);
if strcmp(plot_parameters,'yes')==1
% plot RMSD map
for param=1:13
    if param==1
        name_para='DN';
    elseif param==2
        name_para='DBC';
    elseif param==3
        name_para='DBN';
    elseif param==4
        name_para='k2'; 
    elseif param==5
        name_para='k3';        
    elseif param==6
        name_para='decN';    
    elseif param==7
        name_para='decBC';
    elseif param==8
        name_para='decBN';        
    elseif param==9
        name_para='j1';        
    elseif param==10
        name_para='j2';                
    elseif param==11
        name_para='j3';        
    elseif param==12
        name_para='lambda tld C';
    elseif param==13
        name_para='lambda tld BC';        
    end
figure
scatter(total_RMSD(1,:),total_RMSD(2,:),[],parameter_all(param,:),'filled');
title(['RMSD map wt & chd mutant parameter= ' name_para])
xlabel('wt RMSD')
ylabel('chd mutant RMSD')
cb = colorbar();
cb.Ruler.Scale = 'log';
cb.Ruler.MinorTick = 'on';

%% plot parameter vs rmsd (total 13 plots)
figure
scatter(parameter_all(param,:),total_RMSD(1,:),[],'b')
hold on
scatter(parameter_all(param,:),total_RMSD(2,:),[],'r')
title([name_para ' RMSD']);
xlabel(name_para);
ylabel('RMSD');
legend('WT','CHD Mutant')
set(gca, 'XScale', 'log')
end
end


%% plot min cases
% set another total_RMSD to sort the min 10 casess
total_RMSD_sort=total_RMSD;



for min_case_n = 1:min_case_number
    
f2=figure;
hold on   
    
[min_rmsd_wt,I_rmsd_wt]=min(total_RMSD_sort(1,:));
[min_rmsd_chd,I_rmsd_chd]=min(total_RMSD_sort(2,:));

min_file_wt=floor(I_rmsd_wt/casenum_onfile);
min_case_wt=I_rmsd_wt-(min_file_wt-1)*casenum_onfile;

min_file_chd=floor(I_rmsd_chd/casenum_onfile);
min_case_chd=I_rmsd_chd-(min_file_chd-1)*casenum_onfile;

% plot min case 
for t=result_type
    f1=figure;
    hold on
    if t==1
        ty='wt';
        min_file=min_file_wt;
        min_case=min_case_wt;
        min_rmsd=min_rmsd_wt;
        
    else
        ty='chd';
        min_file=min_file_chd;
        min_case=min_case_chd;
        min_rmsd=min_rmsd_chd;
    end
    
    load(['../' foldername '/grow_result_' num2str(casenum_onfile) '_' num2str(i) '.mat']);
    
    
    
    
    
    % get the mincase result
    min_BMP_case=Total_BMP(:,min_case);
    max_level_bmp=max(max(min_BMP_case{3}));
    min_chd_case=Total_Chd(:,min_case);
    %max_level_chd=max(max(min_chd_case{3}));
    min_Nog_case=Total_Nog(:,min_case);
    %max_level_Nog=max(max(min_Nog_case{3}));

    %count the number for subplt
    sub_count=1;
    
    for hpf=[47,53,57]
    
    if hpf==47
        celln=1;
        c='k';
    elseif hpf==53
        celln=2;
        c='b';
    else
        celln=3;
        c='r';
    end
    figure(f1)
%     % plot 3D 4.7
    min_z=min(min(mesh_zsphere{celln,1}));
    foo1=sample_xyz(:,3)>min_z & sample_xyz(:,2)>= 0;
    eval(['color_data=Avg_wholeSph_' num2str(hpf) '_' ty '(foo1,1);']);
    subplot(3,4,sub_count+1)
    surf(mesh_xsphere{celln,1},mesh_ysphere{celln,1},mesh_zsphere{celln,1},min_BMP_case{celln}/max_level_bmp);
    axis equal
    title([num2str(hpf) 'hpf BMP type:' ty]);
    view([0,0]);
    xlim([-350,350])
    zlim([0,350])
    colorbar;
    
    subplot(3,4,sub_count)
    scatter3(sample_xyz(foo1,1),sample_xyz(foo1,2),sample_xyz(foo1,3),[],color_data,'filled');
    view([0,0]);
    xlim([-350,350])
    zlim([0,350])
    colorbar;
    caxis([0,1])
    title(['pSmad data' num2str(hpf)])
    
    subplot(3,4,sub_count+2)
    surf(mesh_xsphere{celln,1},mesh_ysphere{celln,1},mesh_zsphere{celln,1},min_chd_case{celln});
    axis equal
    title([num2str(hpf) 'hpf CHD type:' ty]);
    view([0,0])
    xlim([-350,350]);
    zlim([0,350]);
    colorbar;
    
    subplot(3,4,sub_count+3)
    surf(mesh_xsphere{celln,1},mesh_ysphere{celln,1},mesh_zsphere{celln,1},min_Nog_case{celln});
    axis equal
    title([num2str(hpf) 'hpf Nog type:' ty]);
    view([0,0]);
    xlim([-350,350]);
    zlim([0,350]);
    colorbar;
    
    sub_count=sub_count+4;

    
    figure(f2)
    % find the margin slice for 
    eval(['last_z_' num2str(hpf) '=min(sample_xyz(~isnan(Avg_wholeSph_' num2str(hpf) '_' ty '),3))+3;'])   
    eval(['margin_' num2str(hpf) '_I=sample_xyz(:,3)>last_z_' num2str(hpf) ' & sample_xyz(:,3)<last_z_' num2str(hpf) '+30;'])
    
    %plot for margin
    subplot (2,2,t)
    title(['Margin Comparison type:' ty ' RMSD=' num2str(min_rmsd) ' best case ' num2str(min_case_n) 'min_file' num2str(min_file) 'min_case' num2str(min_case)]);
    hold on
    eval(['data_margin_' num2str(hpf) '=Avg_wholeSph_' num2str(hpf) '_' ty '(margin_' num2str(hpf) '_I,1);'])
    eval(['data_margin_' num2str(hpf) '_az=abs(sample_mesh(margin_' num2str(hpf) '_I,1)-pi);'])
    eval(['plt_x=data_margin_' num2str(hpf) '_az;'])
    eval(['plt_y=data_margin_' num2str(hpf) ';'])
    scatter(plt_x,plt_y,'filled',c);

    
    [mesh_az,mesh_el,~]=cart2sph(mesh_xsphere{celln,1},mesh_ysphere{celln,1},mesh_zsphere{celln,1});
    mesh_x=mesh_xsphere{celln,1};  
    sim=Total_BMP{celln,min_case}/max_level_bmp;


    plot(abs(mesh_az(:,size(mesh_az,2))-pi),sim(:,size(mesh_az,2)),c,'LineWidth',2);
    
    ylim([0,1.2]);
    
    

    %plot centeral data
    
    subplot(2,2,t+2)
    title(['Central Comparison type:' ty ' RMSD=' num2str(min_rmsd) ' best case ' num2str(min_case_n) 'min_file' num2str(min_file) 'min_case' num2str(min_case)]);
    hold on
    
    % find the central slice for exp data
    eval(['central_z_I=sample_xyz(~isnan(Avg_wholeSph_' num2str(hpf) '_' ty '),2)<10 & sample_xyz(~isnan(Avg_wholeSph_' num2str(hpf) '_' ty '),2)>-10;'])      
    % plot central for average exp result 
    eval(['data_central=Avg_wholeSph_' num2str(hpf) '_' ty '(central_z_I,1);'])
    data_central_el=sample_mesh(central_z_I,2).*(-2*double(sample_mesh(central_z_I,1)>0)+1);
    scatter(data_central_el,data_central,c,'filled');

    
    % plot central for sim result 
    central_sim=[fliplr(sim(size(mesh_el,1),:)),sim(1,:)];
    el_central=[fliplr(mesh_el(size(mesh_el,1),:))-pi/2,-mesh_el(1,:)+pi/2];
    %x_central_47=[fliplr(mesh_x_47(size(mesh_el_47,1),:)),mesh_x_47(1,:)];
    plot(el_central,central_sim,c,'LineWidth',2);

   
    ylim([0,1.2]);
    end
    figure(f1)
    title(['3D result plot for min case ' num2str(min_case)])
    
end

% re set the RMSD of the min one to get the next min 
total_RMSD_sort(1,I_rmsd_wt)=100;
total_RMSD_sort(2,I_rmsd_chd)=100;

figure(f2)
title(['Margin & central plot for min case ' num2str(min_case)])


end
end