

%% code for running the growth model of zebrafish embryo bmp signaling regulation
%% author: Linlin Li
%% last update: 12/06/18
function Run_grow_noplot_expression(total_case_num,filename,case_n,parset,ty)

% foldername=pwd;
%filename='grow_result_5000.mat';
%% load expression database for bmp ( function mathod  
% load('bmp_expression_1.mat');
% expression.mesh_az_sample=mesh_az_sample;
% expression.mesh_el_sample=mesh_el_sample;
% expression.t_sample=t_sample;
% expression.c_sample=time_c;

%% load expression map for chd & BMP
load('makeup_chd_4757_121018.mat')
load('makeup_bmp_4757_121718.mat')

paraset_start=1;
paraset_end=total_case_num;
%save 13 time during the calculation to save the reading time
% savecases=linspace(200,paraset_end,13);
% setting the globle parameters (not changing by parameterscreening)
%===================3D========================
%-------------initialize start node
n1i=9; % on epiboly direction
n2i=15; % on azimuth direction
epiboly_start_thta_ori=0.4;      % epiboly start portion of the very beginning
epiboly_end_thta_e  = 0.5;       % epiboly total end portion (5.7hpf)
durition = 7920;
durition_steps=[4320,2160,1440];
accmulate_t= [4320,6480,7920]; 


% check for growth step correctness
growthlength=(epiboly_end_thta_e- epiboly_start_thta_ori)/(epiboly_start_thta_ori/(n1i-1));

% check for growth step (not work for parafor)!!
check_rem=rem(growthlength,1);
if check_rem>0.01 && check_rem<0.99 % use 0.99 to avoid mechine error 
  sprintf(' error: growing step size not match with the mesh size!')
  return
end

% dthta and dphi will not change during the whold simulaiton
parameters.dthta=epiboly_start_thta_ori/(n1i-1);
parameters.dphi=pi/(n2i-1);

timestep=round(growthlength)+1;

% set embryo size and top pole 
parameters.r = 350;           % embryo redius (not change)
parameters.start_thta = 0;    % start portion of thta angle for pi


%initialize for saving the mesh
mesh_xsphere=cell(timestep,1);
mesh_ysphere=cell(timestep,1);
mesh_zsphere=cell(timestep,1);

%initialize output vectors
Total_BMP=cell(timestep,paraset_end-paraset_start+1);
Total_Chd=cell(timestep,paraset_end-paraset_start+1);
Total_Nog=cell(timestep,paraset_end-paraset_start+1);
Total_BC=cell(timestep,paraset_end-paraset_start+1);
Total_BN=cell(timestep,paraset_end-paraset_start+1);
Total_T= cell(timestep,paraset_end-paraset_start+1);

%initialize a output vectors to save express region
expression_BMP=cell(timestep,paraset_end-paraset_start+1);
expression_Chd=cell(timestep,paraset_end-paraset_start+1);
expression_Nog=cell(timestep,paraset_end-paraset_start+1);
expression_Tld=cell(timestep,paraset_end-paraset_start+1);

% set expression for BMP, Chd and Nog
etaB=cell(timestep,1);
etaC=cell(timestep,1);
etaN=cell(timestep,1);

for l=1:timestep
    end_thta =epiboly_start_thta_ori+(l-1)*parameters.dthta;    % end portion of thta angle for pi (30%=70/180~0.39 50%=0.5)
    node_thta = n1i+(l-1);    % node number on horizonal direction
    node_phi = n2i;     % node number on vertical direction
    
    [thta, phi]=meshgrid(parameters.start_thta*pi:((end_thta-parameters.start_thta)*pi/(node_thta-1)):pi*end_thta,0:pi/(node_phi-1):pi);
    X_sphere=parameters.r.*sin(thta).*cos(phi);
    Y_sphere=parameters.r.*sin(thta).*sin(phi);
    Z_sphere=parameters.r.*cos(thta);
% 
    
    currentt=ones(size(thta,1),size(thta,2)).*accmulate_t(l);

    %chang thta from 
    interp_phi=phi;
    interp_thta=pi/2-thta;
    %% interpolation for bmp/chd expression from exp data
    %etaB_t = interp3(expression.mesh_az_sample,expression.mesh_el_sample,expression.t_sample,expression.c_sample,interp_phi,interp_thta,currentt);
    f_bmp  = scatteredInterpolant(total_bmp_4757(:,5),total_bmp_4757(:,6),total_bmp_4757(:,7),total_bmp_4757(:,4),'linear');
    etaB_t = f_bmp(interp_phi,interp_thta,currentt);
   
    f_chd  = scatteredInterpolant(total_chd_4757(:,5),total_chd_4757(:,6),total_chd_4757(:,7),total_chd_4757(:,4),'linear');
    etaC_t = f_chd(interp_phi,interp_thta,currentt);
    %check out for minus expression
    checkzero= etaB_t<0;
    [col,row]=find(checkzero~=0);
    if ~isempty(col)
        for po=1:length(col)
        etaB_t(col(po),row(po))=(etaB_t(col(po)-1,row(po))+etaB_t(col(po)+1,row(po)))/2; % change the minus expression by the average of naighber nodes
        end
    end
    
    checkzero_c= etaC_t<0 | etaC_t>1;
    etaC_t(checkzero_c)=0;
    %
    % limite etaC_t on marging of 3 node
    etaC_t(:,1:(size(etaC_t,2)-3))=0;
 % set Nog has the same expression area with Chd   
    etaN_t = etaC_t;
    % limite etaC_t on marging of 2 node
    etaN_t(:,1:(size(etaN_t,2)-2))=0;
    etaN_t(X_sphere<300)=0;
    
    % initialize expression matrix
    etaB{l}=etaB_t;
    etaC{l}=etaC_t;
    etaN{l}=etaN_t;
    mesh_xsphere{l}=X_sphere;
    mesh_ysphere{l}=Y_sphere;
    mesh_zsphere{l}=Z_sphere;    
    

end
%initialize parameters set
% total_parameters=zeros(paraset_end-paraset_start+1,1);
%% load parameter_set
load(['parameter_set_' num2str(parset) '.mat'],['parameter_set' num2str(case_n)]);
eval(sprintf('parameter_set=parameter_set%d;',case_n));

for paraset=paraset_start:paraset_end
       %paraset
        % set a name for saving the result
        %tic
        %namef=sprintf('/results/growing_result_1215_%d.mat',paraset);
%         namef = ['growing_result_1215_' num2str(paraset) '.mat'];
%         filename=namef;%[foldername,namef];
        %% Specifying parameters for sphere code and 1D code
        % ======================setting parameters for all time stage==========================

        %S_parameters=ParameterSampling();
        
        parameters.DB = 4.4;        % diffusion rate of BMP         (microns^2*s^-1)*60s*m^-1
        parameters.DC = 7;        % diffusion rate of Chordin         (microns^2*s^-1)*60s*m^-1
        parameters.DN = parameter_set(1,paraset);%S_parameters.DN;        % diffusion rate of Noggin          (microns^2*s^-1)*60s*m^-1
        parameters.DBC = parameter_set(2,paraset);%S_parameters.DBC;      % diffusion rate of [BMP,Chd]       (microns^2*s^-1)*60s*m^-1
        parameters.DBN = parameter_set(3,paraset);%S_parameters.DBN;     % diffusion rate of [BMP,Nog]       (microns^2*s^-1)*60s*m^-1
        
        parameters.k2   = parameter_set(4,paraset);%S_parameters.k2;   % binding rates for BMP ligand and Chordin          nM^-1*m^-1
        parameters.k_2  = parameters.k2;%S_parameters.k_2;  % unbinding rates for BMP ligand and Chordin        m^-1
        parameters.k3   = parameter_set(5,paraset);%S_parameters.k3;   % binding rates for BMP ligand and Noggin           nM^-1*m^-1
        parameters.k_3  = parameters.k3*0.1;%S_parameters.k_3;  % unbinding rates for BMP ligand and Noggin
        
        %%% decay rate
        parameters.decB  = 8.7*10^-5;%S_parameters.decB;   % decay rate of Ligand (BMP)    nM*m^-1
        parameters.decC  = 9.6*10^-5;%S_parameters.decC;   % decay rate of Chd             nM*m^-1
        parameters.decN  = parameter_set(6,paraset);%S_parameters.decN;   % decay rate of Nog             nM*m^-1
        parameters.decBC = parameter_set(7,paraset);%S_parameters.decBC;  % decay rate of BC             nM*m^-1
        parameters.decBN = parameter_set(8,paraset);%S_parameters.decBN;  % decay rate of BN             nM*m^-1
        %%% production rates 
        parameters.j1 = parameter_set(9,paraset);%S_parameters.j1;   % production rate of BMP          nM*m^-1 
        if ty==1
        parameters.j2 = parameter_set(10,paraset);%S_parameters.j2;  % production rate of Chordin  nM*m^-1
        else 
        parameters.j2 = 0; % set expression = 0 when run chd mutant case    
        end
        parameters.j3 = parameter_set(11,paraset);%S_parameters.j3;  % production rate of Noggin       nM*m^-1

        %%% Tolloid behavior
        parameters.lambda_tld_C  = parameter_set(12,paraset);%S_parameters.lambda_tld_C;     % tld processing rate of Chd  nM^-1*m^-1
        parameters.lambda_tld_BC = parameter_set(13,paraset);%S_parameters.lambda_tld_BC;    % tld processing rate of LC   nM^-1*m^-1
        parameters.tld_conc = 0.2;%S_parameters.tld_conc; 
        %======================setting parameters may change by time==========================
        
        parameters.n1=n1i;  % initial Mesh number on thta direction         
        parameters.n2=n2i;  % initial Mesh number on phi direction

        %-------------set growing information
        parameters.epiboly_start_thta=epiboly_start_thta_ori;       % epiboly start portion of thta angle for pi(from 4.7-5.7)
        parameters.epiboly_end_thta=epiboly_end_thta_e;                          % epiboly end portion of thta angle for pi(from 4.7-5.7)
        parameters.total_time_durtion =durition;     % epiboly durtion(from 4.7-5.7)

        parameters.timestep=timestep;   

        %------initialize secration vector
        parameters.B0 = zeros(parameters.n2,parameters.n1);      % initialize BMP vector
        parameters.C0 = zeros(parameters.n2,parameters.n1);      % initialize Chordin vector
        parameters.N0 = zeros(parameters.n2,parameters.n1);      % initialize Noggin vector
        parameters.BC0 = zeros(parameters.n2,parameters.n1);     % initialize BMP_Chordin vector
        parameters.BN0 = zeros(parameters.n2,parameters.n1);     % initialize BMP_Noggin vector
              
        current_t=0;

        for k=1:parameters.timestep

        %sprintf('timestep=%d',k)                   %print out time step

        parameters.end_thta =parameters.epiboly_start_thta+(k-1)*parameters.dthta;    % end portion of thta angle for pi (30%=70/180~0.39 50%=0.5)
        parameters.node_thta = parameters.n1+(k-1);    % node number on horizonal direction
        parameters.node_phi = parameters.n2;     % node number on vertical direction
% 
%         %---conputational setting
%         % tRange=[0,parameters.total_time_durtion/parameters.timestep];            %time range for sim_stepulation
         tRange=[0,durition_steps(k)];%parameters.total_time_durtion/(parameters.timestep+1)];  
%         current_t=current_t+tRange(2)/2;
%         %set initial mesh
%         [thta, phi]=meshgrid(parameters.start_thta*pi:((parameters.end_thta-parameters.start_thta)*pi/(parameters.node_thta-1)):pi*parameters.end_thta,0:pi/(parameters.node_phi-1):pi);
%         X_sphere=parameters.r.*sin(thta).*cos(phi);
%         Y_sphere=parameters.r.*sin(thta).*sin(phi);
%         Z_sphere=parameters.r.*cos(thta);
% 
%         mesh_xsphere{k,paraset}=X_sphere;
%         mesh_ysphere{k,paraset}=Y_sphere;
%         mesh_zsphere{k,paraset}=Z_sphere;

        %===================3D========================
        %---region of expression----------------------
%         currentt=ones(size(thta,1),size(thta,2)).*current_t;
% 
%         %chang thta from 
%         interp_phi=phi;
%         interp_thta=pi/2-thta;
% 
%         etaB = parameters.j1.* interp3(expression.mesh_az_sample,expression.mesh_el_sample,expression.t_sample,expression.c_sample,interp_phi,interp_thta,currentt);
%         f_chd = scatteredInterpolant(total_chd_4757(:,5),total_chd_4757(:,6),total_chd_4757(:,7),total_chd_4757(:,4),'linear');
%         etaC = parameters.j2.* f_chd(interp_phi,interp_thta,currentt);
%         etaN = parameters.j3.* f_chd(interp_phi,interp_thta,currentt);
%         %check out for minus expression
%         checkzero= etaB<0;
%         etaB(checkzero)=0;
% 
%         checkzero_c= etaC<0;
%         etaC(checkzero_c)=0;


%         %set chd nog expression scale number
%         %chd_e=(0.6818*current_t+2477)/(current_t+2477); %interp1(chd_t,chd_num,current_t);
%         %nog_e=(0.722*current_t+3543)/(current_t+3541);  %interp1(chd_t,nog_num,current_t);
        
        %set expression parameters
        parameters.etaB=etaB{k}*parameters.j1;
        parameters.etaC=etaC{k}*parameters.j2;
        parameters.etaN=etaN{k}*parameters.j3;
        %parameters.etaC = parameters.j2.*((X_sphere+parameters.r)/max(max(X_sphere+parameters.r))).^50./(chd_e^50+((X_sphere+parameters.r)/max(max(X_sphere+parameters.r))).^50);
        %parameters.etaN = parameters.j3.*((X_sphere+parameters.r)/max(max(X_sphere+parameters.r))).^50./(nog_e^50+((X_sphere+parameters.r)/max(max(X_sphere+parameters.r))).^50);
        parameters.etaTld = (current_t/(2000+current_t))*parameters.tld_conc*ones(size(parameters.etaB));
        
%         %check expression
%         figure
%         scatter3(X_sphere(:),Y_sphere(:),Z_sphere(:),[],etaB_t(:),'filled');
%         axis equal
%         view([0,0]);
%         caxis([0,1.25]);
%         colorbar;
%         title('bmp')
%         
%         figure
%         scatter3(X_sphere(:),Y_sphere(:),Z_sphere(:),[],etaC_t(:),'filled');
%         axis equal
%         view([0,0]);
%         caxis([0,1]);
%         colorbar;
%         title('chd')
%         
%         figure
%         scatter3(X_sphere(:),Y_sphere(:),Z_sphere(:),[],etaN_t(:),'filled');
%         axis equal
%         view([0,0]);
%         caxis([0,1]);
%         colorbar;
%         title('nog')
%         
%         figure
%         scatter3(X_sphere(:),Y_sphere(:),Z_sphere(:),[],etaTld_t(:),'filled');
%         axis equal
%         view([0,0]);
%         caxis([0,0.2]);
%         colorbar;
%         title('tld')
%        

        %% Main function------------------------------------
    
        [D_out_BMP,D_out_Chd,D_out_Nog,D_out_BC,D_out_BN,T] = SphereFiniDiffMod_expression_1(tRange,parameters);

        Last_BMP=D_out_BMP{length(D_out_BMP)};
        Last_Chd=D_out_Chd{length(D_out_Chd)};
        Last_Nog=D_out_Nog{length(D_out_Nog)};
        Last_BC=D_out_BC{length(D_out_BC)};
        Last_BN=D_out_BN{length(D_out_BN)};

        %updata the initial conditions for next time step
        parameters.B0 = cat(2,Last_BMP,Last_BMP(:,size(Last_BMP,2)));      % initialize BMP vector
        parameters.C0 = cat(2,Last_Chd,Last_Chd(:,size(Last_Chd,2)));      % initialize Chordin vector
        parameters.N0 = cat(2,Last_Nog,Last_Nog(:,size(Last_Nog,2)));      % initialize Noggin vector
        parameters.BC0 = cat(2,Last_BC,Last_BC(:,size(Last_BC,2)));        % initialize BMP_Chordin vector
        parameters.BN0 = cat(2,Last_BN,Last_BN(:,size(Last_BN,2)));        % initialize BMP_Noggin vector

        %save results---------------------------------
        Total_BMP{k,paraset}=Last_BMP;%D_out_BMP;
%         figure
%         surf(X_sphere,Y_sphere,Z_sphere,Last_BMP);
%         title('BMP result')
%         view([0,0]);
% %         caxis([0,3500]);
%         hold on; axis equal;colorbar;
%         
        Total_Chd{k,paraset}=Last_Chd;%D_out_Chd;
%         figure
%         surf(X_sphere,Y_sphere,Z_sphere,Last_Chd);
%         title('Chd result')
%         view([0,0]);
%         caxis([0,0.5]);
%         hold on; axis equal;colorbar;        
%         
      
        Total_Nog{k,paraset}=Last_Nog;%D_out_Nog;
        Total_BC{k,paraset}=Last_BC;%D_out_BC;
        Total_BN{k,paraset}=Last_BN;%D_out_BN;
        Total_T{k,paraset}=T;
        
                % -----------------------save express regions
        expression_BMP{k,paraset}=parameters.etaB;
        expression_Chd{k,paraset}=parameters.etaC;
        expression_Nog{k,paraset}=parameters.etaN;
        expression_Tld{k,paraset}=parameters.etaTld;
        
        %plot to check the expression 
%         figure
%         surf(X_sphere,Y_sphere,Z_sphere,parameters.etaB);
%         title('BMP expression region')
%         hold on; axis equal;colorbar;
%         caxis([0,parameters.j1])
% 
%         figure
%         surf(X_sphere,Y_sphere,Z_sphere,parameters.etaC);
%         title('Chd expression region')
%         hold on; axis equal;colorbar;
% 
%         figure
%         surf(X_sphere,Y_sphere,Z_sphere,etaN);
%         title('Nog expression region')
%         hold on; axis equal;colorbar;
% 
%         figure
%         surf(X_sphere,Y_sphere,Z_sphere,Tld);
%         title('Tld expression region')
%         hold on; axis equal;colorbar;
        
        total_parameters(paraset)=parameters;
        
        % updata current time
        current_t=current_t+tRange(2)/2;
        %current_t=current_t+tRange(2);
        end

        

%toc

%save total results
%if ismember(paraset,savecases)==1
save(filename,'Total_BMP','Total_Chd','Total_Nog','Total_BC','Total_BN','Total_T','expression_BMP','expression_Chd','expression_Nog','expression_Tld','mesh_xsphere','mesh_ysphere','mesh_zsphere','total_parameters')
%end

%plot results
end
%save total results
%save(filename,'Total_BMP','Total_Chd','Total_Nog','Total_BC','Total_BN','Total_T','expression_BMP','expression_Chd','expression_Nog','expression_Tld','mesh_xsphere','mesh_ysphere','mesh_zsphere','total_parameters')
end
% plot_sourcemodel(filename)