clear all
close all



% set up total parallel case and simulaiton number in each case
% need to match with the file structure of file pre sampled parameter_set_1.mat
total_case = 1;
each_case = 1;

%set which parameter set are running
% filename type ['parameter_set_' num2str(parset) '.mat']
paraset = 1;
%% set parallel computing
%parpool(total_case)
%parfor i=1:total_case

% setup the runing case ty=1 for wt and ty=2 for chd mutant
ty = 1;

for i=1:total_case

    filename=sprintf('grow_result_%d_%d.mat',each_case,i);
    Run_grow_noplot_expression(each_case,filename,i,paraset,ty);
end